
function loaded() {
    "use strict";
    setTimeout(function () {
        $('.loader_bg').fadeToggle();
    }, 900);
}
